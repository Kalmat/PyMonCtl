#!/usr/bin/python
# -*- coding: utf-8 -*-

from ._structs import (ScreensInfo, DisplaysInfo, WmHints, Aspect, WmNormalHints)
