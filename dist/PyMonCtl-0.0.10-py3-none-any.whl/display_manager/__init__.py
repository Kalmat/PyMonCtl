#!/usr/bin/python
# -*- coding: utf-8 -*-
# Incomplete type stubs for pyobjc
# mypy: disable_error_code = no-any-return
from __future__ import annotations

import sys
assert sys.platform == "darwin"

from display_manager import *
from display_manager.display_manager_lib import *
